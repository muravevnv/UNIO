
import Swiper from "swiper";
import { Pagination } from "swiper/modules";
import Choices from "choices.js";
import tippy from 'tippy.js';
import AirDatepicker from 'air-datepicker';
import IMask from 'imask'

// Слайдера банера на странице авторизации
if (document.querySelector('[data-slider="auth-banner"]')) {
  const diarySlider = new Swiper('[data-slider="auth-banner"]', {
    modules: [Pagination],
    slidesPerView: 1,
    spaceBetween: 16,
    pagination: {
      el: '.swiper-pagination',
      clickable: true
    }
  });
}


// Фунция для модальных окон
const modalBtns = document.querySelectorAll('[data-modal-target]')
const body = document.querySelector('body');

if(modalBtns.length > 0) {

  const modalCloseBtn = document.querySelectorAll('[data-modal-close]');

  // Открытие модального окна
  function openModal(el) {
    el.classList.add('is-open');
    body.classList.add('no-scroll');
  }
  
  // Закрытие модального окна
  function closeModal(el) {
    el.classList.remove('is-open');
    body.classList.remove('no-scroll');
  }

  document.addEventListener('click', (e) => {
    console.log(e.target)
    if(e.target.classList.contains('overlay')) {
      const closestModal = e.target.closest('[data-modal]');
      closeModal(closestModal);
    }
  })

  modalBtns.forEach((btn) => {
    const modal = document.getElementById(`${btn.dataset.modalTarget}`);
    console.log(modal)
    btn.addEventListener('click', () => {
      openModal(modal);
    });
  });

  modalCloseBtn.forEach((btn) => {
    const modal = btn.closest('[data-modal]');
    btn.addEventListener('click', () => {
      closeModal(modal);
    });
  });
} 


//Функция для показа пароля
const passwordBlocks = document.querySelectorAll('[data-password="block"]');

if(passwordBlocks.length > 0) {

  passwordBlocks.forEach((block) => {
    console.log(block)
    const passwordToggle = block.querySelector('[data-password="toggle"]');
    const passwordInput = block.querySelector('[data-password="input"]');
    console.log(block, passwordToggle, passwordInput)

    const passwordInputType = passwordInput.getAttribute('type');

    passwordToggle.addEventListener('click', () => {
      if (!passwordToggle.classList.contains('is-active')) {
        passwordInput.setAttribute('type', 'text');
        passwordToggle.classList.add('is-active');
      } else {
        passwordInput.setAttribute('type', 'password');
        passwordToggle.classList.remove('is-active');
      }
    })
  })
}

const selects = document.querySelectorAll('select');

if(selects.length > 0) {
  selects.forEach((select) => {
    const choices = new Choices(select, {
      searchEnabled: false,
      itemSelectText: '',
    });
  })
}

const tooltips = document.querySelectorAll('[data-tippy]');
if(tooltips.length > 0) {
  tooltips.forEach((tooltip) => {
    const toolTipContent = tooltip.dataset.content;
    tippy(tooltip, {
      theme: 'custom',
      content: toolTipContent,
      placement: 'bottom-start',
      arrow: false,
    });
  })
}

const datepicker = document.querySelectorAll('[data-datepicker]');
if(datepicker.length > 0) {
  datepicker.forEach((item) => {
    const datepicker = new AirDatepicker(item, {
      clearButton: true,
    });
  })
}

const hiddenContent = document.querySelector('[data-show="content"]');

if(hiddenContent) {

  const hiddenContentBtn = document.querySelector('[data-show="btn"]');

  hiddenContentBtn.addEventListener('click', () => {
    hiddenContentBtn.classList.toggle('is-active');
    hiddenContent.classList.toggle('is-open');
  })
}